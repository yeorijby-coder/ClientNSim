// JobOfflineDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ecs.h"
#include "JobOfflineDlg.h"
#include "EcsDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CJobOfflineDlg dialog


CJobOfflineDlg::CJobOfflineDlg(CEcsDoc* pDoc, CWnd* pParent /* = NULL */)
	: CDialog(CJobOfflineDlg::IDD, pParent)
{
	m_pDoc = pDoc;
	DEBUGER_ASSERT_VALID(m_pDoc != NULL);
	DEBUGER_ASSERT_VALID(m_pDoc->m_pJob != NULL);
	DEBUGER_ASSERT_VALID(m_pDoc->m_pLog != NULL);

	//{{AFX_DATA_INIT(CJobOfflineDlg)
	m_bAutoJob = FALSE;
	//}}AFX_DATA_INIT
}


void CJobOfflineDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CJobOfflineDlg)
	DDX_Control(pDX, IDC_TAB_JOB_TYPE, m_tabJobType);
	DDX_Control(pDX, IDC_COMBO_START_WAREHOUSE, m_cbxStartWH);
	DDX_Control(pDX, IDC_COMBO_DEST_WAREHOUSE, m_cbxDestWH);
	DDX_Control(pDX, IDC_COMBO_START_STATION, m_cbxStartStn);
	DDX_Control(pDX, IDC_COMBO_DEST_STATION, m_cbxDestStn);
	DDX_Control(pDX, IDC_EDIT_START_LOCATION, m_edtStartLoc);
	DDX_Control(pDX, IDC_EDIT_DEST_LOCATION, m_edtDestLoc);
	DDX_Control(pDX, IDC_BUTTON_CREATE, m_btnCreate);
	DDX_Control(pDX, IDOK, m_btnOK);
	DDX_Check(pDX, IDC_CHECK_AUTO, m_bAutoJob);
	DDX_Check(pDX, IDC_CHECK_BIG, m_bBig);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CJobOfflineDlg, CDialog)
	//{{AFX_MSG_MAP(CJobOfflineDlg)
	ON_NOTIFY(TCN_SELCHANGE, IDC_TAB_JOB_TYPE, OnSelchangeTabJobType)
	ON_BN_CLICKED(IDC_BUTTON_CREATE, OnButtonCreate)
	ON_CBN_SELCHANGE(IDC_COMBO_START_WAREHOUSE, OnSelchangeComboStartWarehouse)
	ON_CBN_SELCHANGE(IDC_COMBO_DEST_WAREHOUSE, OnSelchangeComboDestWarehouse)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CJobOfflineDlg message handlers

BOOL CJobOfflineDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	int w = 32, h = 32;
	INIT_BUTTON(m_btnCreate, IDI_RUN, w, h, "���ڵ��۾� ����");
	INIT_BUTTON(m_btnOK, IDI_EXIT, w, h, "â�ݱ�");

	CImageList imageList;
	imageList.Create(32, 32, TRUE, 1, 1);
	imageList.Add(AfxGetApp()->LoadIcon(IDI_CLASSES2));
	imageList.Add(AfxGetApp()->LoadIcon(IDI_CLASSES3));
	imageList.Add(AfxGetApp()->LoadIcon(IDI_CLASSES4));
	imageList.Add(AfxGetApp()->LoadIcon(IDI_CLASSES5));
	imageList.Add(AfxGetApp()->LoadIcon(IDI_CLASSES6));
	m_tabJobType.SetImageList(&imageList);
	imageList.Detach();
	
	///////////////////////////////////////////////////////////////////////////////////////

	m_tabJobType.InsertItem(0, _T("�԰��۾�"), 0);
	m_tabJobType.InsertItem(1, _T("����۾�"), 1);
	m_tabJobType.InsertItem(2, _T("�����̵�"), 2);
	m_tabJobType.InsertItem(3, _T("�̵��۾�"), 3);
//	m_tabJobType.InsertItem(4, _T("â�����̵�"), 4);

	///////////////////////////////////////////////////////////////////////////////////////

	CLib::SetComboBoxWarehouse(m_cbxStartWH);
	m_cbxStartWH.SetCurSel(0);
	UpdateStationInfo(m_cbxStartWH.GetItemData(m_cbxStartWH.GetCurSel()), m_cbxStartStn);

	CLib::SetComboBoxWarehouse(m_cbxDestWH);
	m_cbxDestWH.SetCurSel(0);
	UpdateStationInfo(m_cbxDestWH.GetItemData(m_cbxDestWH.GetCurSel()), m_cbxDestStn);

//	m_cbxGenCode.AddString(_T("����"));
//	m_cbxGenCode.SetItemData(0, 0);
//	CLib::SetComboBoxGenCode(m_cbxGenCode);
//	m_cbxGenCode.SetCurSel(0);

	///////////////////////////////////////////////////////////////////////////////////////

	m_edtStartLoc.LimitText(CLib::enLengthLocation);
	m_edtDestLoc.LimitText(CLib::enLengthLocation);

	LRESULT lResult;
	OnSelchangeTabJobType(NULL, &lResult);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CJobOfflineDlg::OnSelchangeTabJobType(NMHDR* pNMHDR, LRESULT* pResult) 
{
	switch (m_tabJobType.GetCurSel())
	{
	case enSemiSto:
		{
			m_cbxStartStn.EnableWindow(TRUE);
			m_cbxDestStn.EnableWindow(FALSE);

			m_edtStartLoc.EnableWindow(FALSE);
			m_edtDestLoc.EnableWindow(TRUE);
		}
		break;

	case enSemiRet:
		{
			m_cbxStartStn.EnableWindow(FALSE);
			m_cbxDestStn.EnableWindow(TRUE);

			m_edtStartLoc.EnableWindow(TRUE);
			m_edtDestLoc.EnableWindow(FALSE);
		}
		break;

	case enSemiR2R:
		{
			m_cbxStartStn.EnableWindow(FALSE);
			m_cbxDestStn.EnableWindow(FALSE);

			m_edtStartLoc.EnableWindow(TRUE);
			m_edtDestLoc.EnableWindow(TRUE);
		}
		break;

	case enSemiMove:
		{
			m_cbxStartStn.EnableWindow(TRUE);
			m_cbxDestStn.EnableWindow(TRUE);

			m_edtStartLoc.EnableWindow(FALSE);
			m_edtDestLoc.EnableWindow(FALSE);
		}
		break;
/*
	case enSemiW2W:
		{
			m_cbxStartStn.EnableWindow(FALSE);
			m_cbxDestStn.EnableWindow(FALSE);

			m_edtStartLoc.EnableWindow(TRUE);
			m_edtDestLoc.EnableWindow(TRUE);
		}
		break;
*/
	default:
		DEBUGER_ASSERT_VALID(FALSE);
		break;
	}

	*pResult = 0;
}

void CJobOfflineDlg::OnButtonCreate() 
{
	UpdateData(TRUE);
	int nLuggNum = m_pDoc->m_pJob->GenerateOfflineLuggNum();
	if (nLuggNum == 0)
	{
		AfxMessageBox(_T("�۾���ȣ ���� ����!"));
		return;
	}

	CJobItem oJobItem(m_pDoc);
	CJobItem* pJobItem = NULL;
	CStationInfo* pStartStation = NULL;
	CStationInfo* pDestStation = NULL;
	CString strLog, strStartLoc, strDestLoc, str = _T("");

	// �Է¹��� Stage ���� Location ������ ����
	m_edtStartLoc.GetWindowText(str);
	str.Replace(" ", "");
	strStartLoc = (atoi(str) == 301) ? "0100101" : CLib::GetLocation(atoi(str));
	m_edtDestLoc.GetWindowText(str);
	strDestLoc = (atoi(str) == 301) ? "0100101" : CLib::GetLocation(atoi(str));

	if (m_cbxStartWH.GetCurSel() == CB_ERR)
	{
		AfxMessageBox(_T("���â���� �������ּ���!"));
		return;
	}
	int nStartWH = m_cbxStartWH.GetItemData(m_cbxStartWH.GetCurSel());

	if (m_cbxDestWH.GetCurSel() == CB_ERR)
	{
		AfxMessageBox(_T("����â���� �������ּ���!"));
		return;
	}
	int nDestWH = m_cbxDestWH.GetItemData(m_cbxDestWH.GetCurSel());

	switch (m_tabJobType.GetCurSel())
	{
	case enSemiSto:
		{
			if (m_cbxStartStn.GetCurSel() == CB_ERR)
			{
				AfxMessageBox(_T("������� �������ּ���!"));
				return;
			}

			if ((CLib::IsValidLocation(nDestWH, strDestLoc) == FALSE) || (CLib::GetStackerNum(nDestWH, strDestLoc) == 0))
			{
				AfxMessageBox(_T("LOCATION�� Ȯ�����ּ���!"));
				return;
			}

			if (CLib::IsDisableLocation(nDestWH, strDestLoc))
			{
				AfxMessageBox(_T("������ LOCATION �Դϴ�. Ȯ�����ּ���!"));
				return;
			}

			pStartStation = (CStationInfo*)m_cbxStartStn.GetItemDataPtr(m_cbxStartStn.GetCurSel());
			pDestStation = m_pDoc->GetScStationInfo(nDestWH, strDestLoc);
			DEBUGER_ASSERT_VALID(pStartStation != NULL);
			DEBUGER_ASSERT_VALID(pDestStation != NULL);

//			if (pStartStation->m_pTrack->IsStoStationReady() == FALSE)
			if (pStartStation->m_pTrack->IsScStoHsReady() == FALSE)
			{
				if (AfxMessageBox(_T("����� �۾��� ���°� �غ���� �ʾҽ��ϴ�. ��� �����Ͻðڽ��ϱ�?"), MB_OKCANCEL) != IDOK)
					return;
			}

			if (pJobItem = m_pDoc->m_pJob->FetchReservedJobByStartStation(pStartStation->m_strID))
			{
				if (AfxMessageBox(_T("�ش� ������� �������� �۾��� �����մϴ�. ��� �����Ͻðڽ��ϱ�?\n\n") + pJobItem->GetLogString(), MB_OKCANCEL) != IDOK)
					return;
			}

			oJobItem.m_nLuggNum		= nLuggNum;
			oJobItem.m_nJobType		= (m_bAutoJob) ? enJobTypeAutoSto : enJobTypeSemiSto;
			oJobItem.m_nStartWH		= nStartWH;
			oJobItem.m_strStartStn	= pStartStation->m_strID;
			oJobItem.m_nDestWH		= nDestWH;
			oJobItem.m_strDestStn	= pDestStation->m_strID;
			oJobItem.m_strDestLoc	= strDestLoc;
			oJobItem.m_nSize		= 0;	// Tray Type
		}
		break;

	case enSemiRet:
		{
			if ((CLib::IsValidLocation(nStartWH, strStartLoc) == FALSE) || (CLib::GetStackerNum(nStartWH, strStartLoc) == 0))
			{
				AfxMessageBox(_T("LOCATION�� Ȯ�����ּ���!"));
				return;
			}

			if (CLib::IsDisableLocation(nStartWH, strStartLoc))
			{
				AfxMessageBox(_T("������ LOCATION �Դϴ�. Ȯ�����ּ���!"));
				return;
			}

			if (m_cbxDestStn.GetCurSel() == CB_ERR)
			{
				AfxMessageBox(_T("�������� �������ּ���!"));
				return;
			}

			pStartStation = m_pDoc->GetScStationInfo(nStartWH, strStartLoc);
			pDestStation = (CStationInfo*)m_cbxDestStn.GetItemDataPtr(m_cbxDestStn.GetCurSel());
			DEBUGER_ASSERT_VALID(pStartStation != NULL);
			DEBUGER_ASSERT_VALID(pDestStation != NULL);

			oJobItem.m_nLuggNum		= nLuggNum;
			oJobItem.m_nJobType		= (m_bAutoJob) ? enJobTypeAutoRet : enJobTypeSemiRet;
			oJobItem.m_nStartWH		= nStartWH;
			oJobItem.m_strStartStn	= pStartStation->m_strID;
			oJobItem.m_strStartLoc	= strStartLoc;
			oJobItem.m_nDestWH		= nDestWH;
			oJobItem.m_strDestStn	= pDestStation->m_strID;
			oJobItem.m_nSize		= 0;	// Tray Type
		}
		break;

	case enSemiR2R:
		{
			if (m_cbxStartWH.GetCurSel() != m_cbxDestWH.GetCurSel())
			{
				AfxMessageBox(_T("���â���� ����â���� ���� �������ּ���!"));
				return;
			}

			if ((CLib::IsValidLocation(nStartWH, strStartLoc) == FALSE) || (CLib::GetStackerNum(nStartWH, strStartLoc) == 0))
			{
				AfxMessageBox(_T("����� LOCATION�� Ȯ�����ּ���!"));
				return;
			}

			if (CLib::IsDisableLocation(nStartWH, strStartLoc))
			{
				AfxMessageBox(_T("������ ����� LOCATION �Դϴ�. Ȯ�����ּ���!"));
				return;
			}

			if ((CLib::IsValidLocation(nDestWH, strDestLoc) == FALSE) || (CLib::GetStackerNum(nDestWH, strDestLoc) == 0))
			{
				AfxMessageBox(_T("������ LOCATION�� Ȯ�����ּ���!"));
				return;
			}

			if (CLib::IsDisableLocation(nDestWH, strDestLoc))
			{
				AfxMessageBox(_T("������ ������ LOCATION �Դϴ�. Ȯ�����ּ���!"));
				return;
			}

			if (CLib::GetStackerNum(nStartWH, strStartLoc) != CLib::GetStackerNum(nDestWH, strDestLoc))
			{
				AfxMessageBox(_T("������� �������� LOCATION�� ����ȣ���� S/C�۾��� �ƴմϴ�. Ȯ�����ּ���!"));
				return;
			}

			if ( strStartLoc == strDestLoc)
			{
				AfxMessageBox(_T("������� LOCATION�� �������� LOCATION�� �����ϴ�. Ȯ���� �ּ���!"));
				return;
			}
			
			pStartStation = m_pDoc->GetScStationInfo(nStartWH, strStartLoc);
			pDestStation = m_pDoc->GetScStationInfo(nDestWH, strDestLoc);
			DEBUGER_ASSERT_VALID(pStartStation != NULL);
			DEBUGER_ASSERT_VALID(pDestStation != NULL);

			oJobItem.m_nLuggNum		= nLuggNum;
			oJobItem.m_nJobType		= (m_bAutoJob) ? enJobTypeAutoR2R : enJobTypeSemiR2R;
			oJobItem.m_nStartWH		= nStartWH;
			oJobItem.m_strStartStn	= pStartStation->m_strID;
			oJobItem.m_strStartLoc	= strStartLoc;
			oJobItem.m_nDestWH		= nDestWH;
			oJobItem.m_strDestStn	= pDestStation->m_strID;
			oJobItem.m_strDestLoc	= strDestLoc;
			oJobItem.m_nSize		= 0;	// Tray Type
		}
		break;

	case enSemiMove:
		{
			if (m_cbxStartStn.GetCurSel() == CB_ERR)
			{
				AfxMessageBox(_T("������� �������ּ���!"));
				return;
			}

			if (m_cbxDestStn.GetCurSel() == CB_ERR)
			{
				AfxMessageBox(_T("�������� �������ּ���!"));
				return;
			}


			pStartStation = (CStationInfo*)m_cbxStartStn.GetItemDataPtr(m_cbxStartStn.GetCurSel());
			pDestStation = (CStationInfo*)m_cbxDestStn.GetItemDataPtr(m_cbxDestStn.GetCurSel());
			DEBUGER_ASSERT_VALID(pStartStation != NULL);
			DEBUGER_ASSERT_VALID(pDestStation != NULL);

			if ( pStartStation->m_strID == pDestStation->m_strID)
			{
				AfxMessageBox(_T("������� �������� Station ��ȣ�� �����ϴ�. Ȯ���� �ּ���!"));
				return;
			}

			oJobItem.m_nLuggNum		= nLuggNum;
			oJobItem.m_nJobType		= (m_bAutoJob) ? enJobTypeAutoMove : enJobTypeSemiMove;
			oJobItem.m_nStartWH		= nStartWH;
			oJobItem.m_strStartStn	= pStartStation->m_strID;
			oJobItem.m_nDestWH		= nDestWH;
			oJobItem.m_strDestStn	= pDestStation->m_strID;
			oJobItem.m_nSize		= 0;	// Tray Type
		}
		break;

	case enSemiW2W:
		{
			if (m_cbxStartWH.GetCurSel() == m_cbxDestWH.GetCurSel())
			{
				AfxMessageBox(_T("���â���� ����â���� �ٸ��� �������ּ���!"));
				return;
			}

			if ((CLib::IsValidLocation(nStartWH, strStartLoc) == FALSE) || (CLib::GetStackerNum(nStartWH, strStartLoc) == 0))
			{
				AfxMessageBox(_T("����� LOCATION�� Ȯ�����ּ���!"));
				return;
			}

			if (CLib::IsDisableLocation(nStartWH, strStartLoc))
			{
				AfxMessageBox(_T("������ ����� LOCATION �Դϴ�. Ȯ�����ּ���!"));
				return;
			}

			if ((CLib::IsValidLocation(nDestWH, strDestLoc) == FALSE) || (CLib::GetStackerNum(nDestWH, strDestLoc) == 0))
			{
				AfxMessageBox(_T("������ LOCATION�� Ȯ�����ּ���!"));
				return;
			}

			if (CLib::IsDisableLocation(nDestWH, strDestLoc))
			{
				AfxMessageBox(_T("������ ������ LOCATION �Դϴ�. Ȯ�����ּ���!"));
				return;
			}

			if (CLib::GetStackerNum(nStartWH, strStartLoc) == CLib::GetStackerNum(nDestWH, strDestLoc))
			{
				AfxMessageBox(_T("������� �������� LOCATION�� ����ȣ���� S/C�۾��Դϴ�. Ȯ�����ּ���!"));
				return;
			}

			pStartStation = m_pDoc->GetScStationInfo(nStartWH, strStartLoc);
			pDestStation = m_pDoc->GetScStationInfo(nDestWH, strDestLoc);
			DEBUGER_ASSERT_VALID(pStartStation != NULL);
			DEBUGER_ASSERT_VALID(pDestStation != NULL);

			oJobItem.m_nLuggNum		= nLuggNum;
			oJobItem.m_nJobType		= (m_bAutoJob) ? enJobTypeAutoW2W : enJobTypeSemiW2W;
			oJobItem.m_nStartWH		= nStartWH;
			oJobItem.m_strStartStn	= pStartStation->m_strID;
			oJobItem.m_strStartLoc	= strStartLoc;
			oJobItem.m_nDestWH		= nDestWH;
			oJobItem.m_strDestStn	= pDestStation->m_strID;
			oJobItem.m_strDestLoc	= strDestLoc;
			oJobItem.m_nSize		= 0;	// Tray Type
		}
		break;

	default:
		DEBUGER_ASSERT_VALID(FALSE);
		break;
	}

	if (AfxMessageBox(_T("�۾��� �����Ͻðڽ��ϱ�?"), MB_OKCANCEL) != IDOK)
		return;

	if ((pJobItem = m_pDoc->m_pJob->Add(oJobItem)) == NULL)
	{
		AfxMessageBox(oJobItem.GetJobTypeString() + _T(" �۾����� ����!"));
		return;
	}

	strLog.Format(_T("%s �۾�����"), oJobItem.GetJobTypeString());
	m_pDoc->WriteLog(LOG_TYPE_EVENT, LOG_POS_SYSTEM, strLog, _T("CJobOfflineDlg::OnButtonCreate"), pJobItem);

	if (m_pDoc->m_pJob->Invoke(pJobItem) == FALSE)
	{
		AfxMessageBox(oJobItem.GetJobTypeString() + _T(" �۾����� ����!"));
//		return;
	}
}

void CJobOfflineDlg::UpdateStationInfo(int nWarehouse, CComboBox& cbxStation)
{
	if (!CJobItem::IsValidWarehouse(nWarehouse))
	{
		AfxMessageBox(_T("��ȿ���� ���� â����ȣ�Դϴ�!"));
		return;
	}
/*
	cbxStation.ResetContent();
	CStationInfo* pStation = NULL;
	for (int i=0; i<m_pDoc->m_pStationInfos.GetSize(); ++i)
	{
		pStation = m_pDoc->m_pStationInfos[i];
		DEBUGER_ASSERT_VALID(pStation != NULL);

		if (pStation->GetWarehouseNo() != nWarehouse)
			continue;

		switch (cbxStation.GetDlgCtrlID())
		{
		case IDC_CBX_DEPART:
			if ((pStation->m_enKind == CStationInfo::enStoStation) || (pStation->m_enKind == CStationInfo::enArvStation))
			{
				m_cbxStartStn.AddString(pStation->m_strName);
				m_cbxStartStn.SetItemDataPtr(m_cbxStartStn.GetCount()-1, (void*)pStation);
			}
			break;

		case IDC_CBX_ARRIVE:
			if ((pStation->m_enKind == CStationInfo::enRetStation) || (pStation->m_enKind == CStationInfo::enArvStation))
			{
				m_cbxDestStn.AddString(pStation->m_strName);
				m_cbxDestStn.SetItemDataPtr(m_cbxDestStn.GetCount()-1, (void*)pStation);
			}
			break;

		default:
			DEBUGER_ASSERT_VALID(FALSE);
			return;
		}
	}
*/
}

void CJobOfflineDlg::OnSelchangeComboStartWarehouse() 
{
	if (m_cbxStartWH.GetCurSel() == CB_ERR)
		return;

	UpdateStationInfo(m_cbxStartWH.GetItemData(m_cbxStartWH.GetCurSel()), m_cbxStartStn);
}

void CJobOfflineDlg::OnSelchangeComboDestWarehouse() 
{
	if (m_cbxDestWH.GetCurSel() == CB_ERR)
		return;

	UpdateStationInfo(m_cbxDestWH.GetItemData(m_cbxDestWH.GetCurSel()), m_cbxDestStn);
}
