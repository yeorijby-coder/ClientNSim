// MelsecEthernetSk.cpp: implementation of the CMelsecEthernetSk class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ecs.h"
#include "MelsecEthernetSk.h"
#include "Equipment.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

IMPLEMENT_DYNAMIC(CMelsecEthernetSk, CInterfaceSk)

CMelsecEthernetSk::CMelsecEthernetSk(CEquipment* pEquipment, int nIndex) : CInterfaceSk(pEquipment, nIndex)
{
	m_bReceiving = FALSE;
	m_nIndex = nIndex;
}

CMelsecEthernetSk::~CMelsecEthernetSk()
{
	m_bReceiving = FALSE;

}

BOOL CMelsecEthernetSk::CheckRequest(CByteArray& arrRxData)
{
	CByteArray arrBuffer;

	if (!RecvData(arrBuffer))
		return FALSE;

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	int nRecvLen = arrBuffer.GetSize();
	int nTotalLen = 21;
	if (nRecvLen < nTotalLen)
	{
		m_strLog.Format(_T("���� ������ ���� �̻�! [����=%d, ����=%d]"), nTotalLen, nRecvLen);
		return FALSE;
	}

	if (arrBuffer[0] != 0x50 || arrBuffer[1] != 0x00)		// SUB HEADER
	{
		m_strLog.Format(_T("���� ������ SUB HEADER �̻�!"));
		return FALSE;
	}

	if (arrBuffer[2] != 0x00 || arrBuffer[3] != 0xFF)		// Network NO, PC NO
	{
		m_strLog.Format(_T("���� ������ NETWORK OR PC NO �̻�!"));
		return FALSE;
	}

	if (arrBuffer[4] != 0xFF || arrBuffer[5] != 0x03 || arrBuffer[6] != 0x00)   // Specific value
	{
		m_strLog.Format(_T("���� ������ SPECIFIC VALUE �̻�!"));
		return FALSE;
	}

	/*
	if ((arrBuffer[7] != 0x0C && arrBuffer[7] != 0x10) || arrBuffer[8] != 0x00)   // Specific value
	{
		m_strLog.Format(_T("���� ������ SPECIFIC VALUE �̻�!"));
		int aaa=arrBuffer[7];
		int bbb=arrBuffer[8];
		return FALSE;
	}
	*/

	arrRxData.SetSize(nRecvLen);
	for (int i=0; i<arrRxData.GetSize(); ++i)
		arrRxData[i] = arrBuffer[i];

	return TRUE;
}

BOOL CMelsecEthernetSk::ResponseReadWord(CByteArray& arrTxData, int nLen)
{
	CByteArray arrBuffer;
	arrBuffer.SetSize(11+(nLen*2));

    arrBuffer[0]  = 0xD0;  
	arrBuffer[1]  = 0x00;							// Subheader	

	arrBuffer[2]  = 0x00;							// Network No. (Self station)
	arrBuffer[3]  = 0xFF;							// PC No.

    arrBuffer[4]  = 0xFF;	
	arrBuffer[5]  = 0x03;							// Specific value
	arrBuffer[6]  = 0x00;							// Specific value 2

	
	arrBuffer[7] = (nLen*2+2) & 0xFF;				// LOW 
	arrBuffer[8] = ((nLen*2+2) >> 8) & 0xFF;			// HIGH

	int kkk = (arrBuffer[8] << 8 ) | arrBuffer[7];
//	arrBuffer[7]  = 0x0C;
//	arrBuffer[8]  = 0x00;							// Request data length

	arrBuffer[9]  = 0x00;							// 0x04;
	arrBuffer[10] = 0x00;							// CPU monitoring timer (unit is 250ms)

	for (int i=0; i<nLen*2; ++i)
		arrBuffer[11+i] = arrTxData[i];
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	//arrBuffer.Append(arrTxData);
    if (!SendData(arrBuffer))
		return FALSE;

	return TRUE;
}

BOOL CMelsecEthernetSk::ResponseWriteWord(CByteArray& arrTxData, int nLen)
{
	CByteArray arrBuffer;
	arrBuffer.SetSize(11);

    arrBuffer[0]  = 0xD0;  
	arrBuffer[1]  = 0x00;							// Subheader	

	arrBuffer[2]  = 0x00;							// Network No. (Self station)
	arrBuffer[3]  = 0xFF;							// PC No.

    arrBuffer[4]  = 0xFF;	
	arrBuffer[5]  = 0x03;							// Specific value
	arrBuffer[6]  = 0x00;							// Specific value 2

//	arrBuffer[7]  = 0x00;
	arrBuffer[7]  = 0x00;
	arrBuffer[8]  = 0x00;							// Request data length

	arrBuffer[9]  = 0x00;							// 0x04;
	arrBuffer[10] = 0x00;							// CPU monitoring timer (unit is 250ms)

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	//arrBuffer.Append(arrTxData);
    if (!SendData(arrBuffer))
		return FALSE;

	return TRUE;
}

BOOL CMelsecEthernetSk::ReadWord(CByteArray& arrRxData, int nStartWord, int nWordLen)
{
	CByteArray arrBuffer;
	arrBuffer.SetSize(21);

    arrBuffer[0]  = 0x50;  
	arrBuffer[1]  = 0x00;							// Subheader	

	arrBuffer[2]  = 0x00;							// Network No. (Self station)
	arrBuffer[3]  = 0xFF;							// PC No.

    arrBuffer[4]  = 0xFF;	
	arrBuffer[5]  = 0x03;							// Specific value
	arrBuffer[6]  = 0x00;							// Specific value 2

	arrBuffer[7] = 0x0C;				// LOW 
	arrBuffer[8] = 0x00;			// HIGH

	arrBuffer[9]  = 0x08;							// 0x04;
	arrBuffer[10] = 0x00;							// CPU monitoring timer (unit is 250ms)

	arrBuffer[11] = 0x01;
	arrBuffer[12] = 0x04;							// Command
	arrBuffer[13] = enCmdWordUnit;
	arrBuffer[14] = 0x00; 							// Subcommand

	arrBuffer[15] = (nStartWord & 0xFF);
	arrBuffer[16] = (nStartWord >> 8) & 0xFF;
	arrBuffer[17] = (nStartWord >> 16) & 0xFF;		// Head device (Start Address)

	arrBuffer[18] = enDeviceCodeD;					// Device code (Memory Type)

	arrBuffer[19] = nWordLen & 0x00FF;				// WORD����:���� �����, BIT����:���� ��Ʈ��
	arrBuffer[20] = (nWordLen >> 8) & 0x00FF;		// Number of device points


	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	if (!SendData(arrBuffer))
		return FALSE;

	if (!RecvWait(m_nIndex))
		return FALSE;

	if (!RecvData(arrBuffer))
		return FALSE;

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	int nRecvLen = arrBuffer.GetSize();
	int nTotalLen = enBinaryHeaderLen + nWordLen*2;
	if (nRecvLen < nTotalLen)
	{
		m_strLog.Format(_T("���� ������ ���� �̻�! [����=%d, ����=%d]"), nTotalLen, nRecvLen);
		return FALSE;
	}

	if (arrBuffer[0] != 0xD0 || arrBuffer[1] != 0x00)		// SUB HEADER
	{
		m_strLog.Format(_T("���� ������ SUB HEADER �̻�!"));
		return FALSE;
	}

	if (arrBuffer[2] != 0x00 || arrBuffer[3] != 0xFF)		// Network NO, PC NO
	{
		m_strLog.Format(_T("���� ������ NETWORK OR PC NO �̻�!"));
		return FALSE;
	}

	if (arrBuffer[4] != 0xFF || arrBuffer[5] != 0x03 || arrBuffer[6] != 0x00)   // Specific value
	{
		m_strLog.Format(_T("���� ������ SPECIFIC VALUE �̻�!"));
		return FALSE;
	}

	WORD wErrorCode = (WORD)((arrBuffer[10] << 8) | arrBuffer[9]);
	if (wErrorCode)
	{
		m_strLog.Format(_T("���� ������ ����! [ERROR=%d]"), wErrorCode);
		return FALSE;
	}

	arrRxData.SetSize(nWordLen*2);
	for (int i=0; i<arrRxData.GetSize(); ++i)
		arrRxData[i] = arrBuffer[enBinaryHeaderLen+i];

	return TRUE;
}

BOOL CMelsecEthernetSk::WriteWord(CByteArray& arrTxData, int nStartWord, int nWordLen)
{
	WORD wReqLen = 12 + nWordLen * 2;
	CByteArray arrBuffer;
	arrBuffer.SetSize(21);

    arrBuffer[0]  = 0x50;  
	arrBuffer[1]  = 0x00;						// Subheader	

	arrBuffer[2]  = 0x00;						// Network No. (Self station)
	arrBuffer[3]  = 0xFF;						// PC No.

    arrBuffer[4]  = 0xFF;	
	arrBuffer[5]  = 0x03;						// Specific value
	arrBuffer[6]  = 0x00;						// Specific value 2

	arrBuffer[7]  = wReqLen & 0x00FF;
	arrBuffer[8]  = (wReqLen >> 8) & 0x00FF;  	// Request data length

	arrBuffer[9]  = 0x08;						// 0x04;
	arrBuffer[10] = 0x00;						// CPU monitoring timer (unit is 250ms)

	arrBuffer[11] = 0x01;
	arrBuffer[12] = 0x14;						// Command
	arrBuffer[13] = enCmdWordUnit;
	arrBuffer[14] = 0x00; 						// Subcommand

	arrBuffer[15] = (nStartWord & 0xFF);
	arrBuffer[16] = (nStartWord >> 8) & 0xFF;
	arrBuffer[17] = (nStartWord >> 16) & 0xFF;	// Head device (Start Address)

	arrBuffer[18] = enDeviceCodeD;				// Device code (Memory Type)

	arrBuffer[19] = nWordLen & 0x00FF;			// WORD����:�� �����, BIT����:�� ��Ʈ��
	arrBuffer[20] = (nWordLen >> 8) & 0x00FF;	// Number of device points

	arrBuffer.Append(arrTxData);

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	if (!SendData(arrBuffer))
		return FALSE;

	if (!RecvWait(m_nIndex))
		return FALSE;

	if (!RecvData(arrBuffer))
		return FALSE;

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	if (arrBuffer.GetSize() < enBinaryHeaderLen)
	{
		m_strLog.Format(_T("���� ������ ���� �̻�! [LEN=%d]"), arrBuffer.GetSize());
		return FALSE;
	}

	if (arrBuffer[0] != 0xD0 || arrBuffer[1] != 0x00)		// SUB HEADER
	{
		m_strLog.Format(_T("���� ������ SUB HEADER �̻�!"));
		return FALSE;
	}

	if (arrBuffer[2] != 0x00 || arrBuffer[3] != 0xFF)		// Network NO, PC NO
	{
		m_strLog.Format(_T("���� ������ NETWORK OR PC NO �̻�!"));
		return FALSE;
	}

	if (arrBuffer[4] != 0xFF || arrBuffer[5] != 0x03 || arrBuffer[6] != 0x00)   // Specific value
	{
		m_strLog.Format(_T("���� ������ SPECIFIC VALUE �̻�!"));
		return FALSE;
	}

	WORD wErrorCode = (WORD)((arrBuffer[10] << 8) | arrBuffer[9]);
	if (wErrorCode)
	{
		m_strLog.Format(_T("���� ������ ����! [ERROR=%d]"), wErrorCode);
		return FALSE;
	}

	return TRUE;
}

BOOL CMelsecEthernetSk::Read(int nUnitType, BYTE *pRxBuff, BYTE DeviceCode, int nStartAddr, WORD wReadLen)
{
	m_strErrMsg = "";

	BYTE TxBuff[1024];
	memset(TxBuff, 0x00, sizeof(TxBuff));

    TxBuff[0]  = 0x50;  
	TxBuff[1]  = 0x00;	// Subheader	

	TxBuff[2]  = 0x00;	// Network No. (Self station)
	TxBuff[3]  = 0xFF;	// PC No.

    TxBuff[4]  = 0xFF;	
	TxBuff[5]  = 0x03;	// Specific value
	TxBuff[6]  = 0x00;	// Specific value 2

	TxBuff[7]  = 0x0C;
	TxBuff[8]  = 0x00;	// Request data length

	TxBuff[9]  = 0x08;  // 0x04;
	TxBuff[10] = 0x00;	// CPU monitoring timer (unit is 250ms)

	TxBuff[11] = 0x01;
	TxBuff[12] = 0x04;  //Command
	TxBuff[13] = nUnitType;
	TxBuff[14] = 0x00; 	// Subcommand

	TxBuff[15] = (nStartAddr & 0xFF);
	TxBuff[16] = (nStartAddr >> 8) & 0xFF;
	TxBuff[17] = (nStartAddr >> 16) & 0xFF;		// Head device (Start Address)

	TxBuff[18] = DeviceCode;					// Device code (Memory Type)

	TxBuff[19] = wReadLen & 0x00FF;				//WORD����:���� �����, BIT����:���� ��Ʈ��
	TxBuff[20] = (wReadLen >> 8) & 0x00FF;		// Number of device points

	Sleep(30);

//	if (!SendData(arrBuffer))
//		return FALSE;

	if(Send(TxBuff, 21) == SOCKET_ERROR )
	{
		m_strErrMsg.Format(_T("Read.. �۽� ���� [%s]"), CLib::GetSystemErrMsg());
		return FALSE;
	}

	return RecvReadAck(nUnitType, pRxBuff, wReadLen);
}

BOOL CMelsecEthernetSk::Write(int nUnitType, BYTE *pTxBuff, BYTE DeviceCode, int nStartAddr, WORD wWriteLen)
{
	m_strErrMsg = "";

	BYTE TxBuff[1024];
	memset(TxBuff, 0x00, sizeof(TxBuff));
	WORD wReqLen = 12 + GetDataLength(nUnitType, wWriteLen);

    TxBuff[0]  = 0x50;  
	TxBuff[1]  = 0x00;	// Subheader	

	TxBuff[2]  = 0x00;	// Network No. (Self station)
	TxBuff[3]  = 0xFF;	// PC No.

    TxBuff[4]  = 0xFF;	
	TxBuff[5]  = 0x03;	// Specific value
	TxBuff[6]  = 0x00;	// Specific value 2

	TxBuff[7]  = wReqLen & 0x00FF;
	TxBuff[8]  = (wReqLen >> 8) & 0x00FF;  	// Request data length

	TxBuff[9]  = 0x08;  // 0x04;
	TxBuff[10] = 0x00;	// CPU monitoring timer (unit is 250ms)

	TxBuff[11] = 0x01;
	TxBuff[12] = 0x14;  //Command
	TxBuff[13] = nUnitType;
	TxBuff[14] = 0x00; 	// Subcommand

	TxBuff[15] = (nStartAddr & 0xFF);
	TxBuff[16] = (nStartAddr >> 8) & 0xFF;
	TxBuff[17] = (nStartAddr >> 16) & 0xFF;		// Head device (Start Address)

	TxBuff[18] = DeviceCode;					// Device code (Memory Type)

	TxBuff[19] = wWriteLen & 0x00FF;            //WORD����:�� �����, BIT����:�� ��Ʈ��
	TxBuff[20] = (wWriteLen >> 8) & 0x00FF;		// Number of device points

	memcpy(TxBuff+21, pTxBuff, GetDataLength(nUnitType, wWriteLen));
	int nLen = 21 + GetDataLength(nUnitType, wWriteLen);

	if( Send(TxBuff, nLen) == SOCKET_ERROR )
	{
		m_strErrMsg.Format(_T("Write.. �۽� ���� [%s]"), CLib::GetSystemErrMsg());
		return FALSE;
	}

//	return RecvWriteAck();
	if (!RecvWait(m_nIndex))
		return FALSE;

	CByteArray arrBuffer;
	arrBuffer.SetSize(21);

	if (!RecvData(arrBuffer))
		return FALSE;

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	if (arrBuffer.GetSize() < enBinaryHeaderLen)
	{
		m_strLog.Format(_T("���� ������ ���� �̻�! [LEN=%d]"), arrBuffer.GetSize());
		return FALSE;
	}

	if (arrBuffer[0] != 0xD0 || arrBuffer[1] != 0x00)		// SUB HEADER
	{
		m_strLog.Format(_T("���� ������ SUB HEADER �̻�!"));
		return FALSE;
	}

	if (arrBuffer[2] != 0x00 || arrBuffer[3] != 0xFF)		// Network NO, PC NO
	{
		m_strLog.Format(_T("���� ������ NETWORK OR PC NO �̻�!"));
		return FALSE;
	}

	if (arrBuffer[4] != 0xFF || arrBuffer[5] != 0x03 || arrBuffer[6] != 0x00)   // Specific value
	{
		m_strLog.Format(_T("���� ������ SPECIFIC VALUE �̻�!"));
		return FALSE;
	}

	WORD wErrorCode = (WORD)((arrBuffer[10] << 8) | arrBuffer[9]);
	if (wErrorCode)
	{
		m_strLog.Format(_T("���� ������ ����! [ERROR=%d]"), wErrorCode);
		return FALSE;
	}
	return TRUE;
}

BOOL CMelsecEthernetSk::RecvReadAck(int nUnitType, BYTE *pRxBuff, WORD wReadLen)
{
	int nRecvLen = 0;
	BYTE RxBuff[20000];
	memset(RxBuff, 0x00, sizeof(RxBuff));

	if((nRecvLen = RecvFrame(RxBuff)) == FALSE)		return FALSE;

	if(RxBuff[0] != 0xD0 || RxBuff[1] != 0x00)                //Subheader
	{
		m_strErrMsg.Format(_T("RecvReadAck.. Subheader �̻�.."));
		return FALSE;
	}
	if(RxBuff[2] != 0x00 || RxBuff[3] != 0xFF)                // Network NO, PC NO
	{
		m_strErrMsg.Format(_T("RecvReadAck.. Network or PC NO �̻�.."));
		return FALSE;
	}
	if(RxBuff[4] != 0xFF || RxBuff[5] != 0x03 || RxBuff[6] != 0x00)   // Specific value
	{
		m_strErrMsg.Format(_T("RecvReadAck.. Specific Value �̻�.."));
		return FALSE;
	}

	WORD wErrNo = SwapToWord(RxBuff+9);
	if(wErrNo)
	{
		m_strErrMsg.Format(_T("RecvReadAck.. ���� ����.. �����ڵ�[%d]"), wErrNo);
		return FALSE;
	}

	int nTotalLen = BINARY_HEADER_LEN + GetDataLength(nUnitType, wReadLen);
	if(nTotalLen != nRecvLen)
	{
		m_strErrMsg.Format(_T("RecvReadAck.. ���� ������ ���� �̻�[��ü%d - ����%d]"), nTotalLen, nRecvLen);
		return FALSE;
	}

	memcpy(pRxBuff, RxBuff+BINARY_HEADER_LEN, GetDataLength(nUnitType, wReadLen));

	return TRUE;
}

BOOL CMelsecEthernetSk::RecvWriteAck()
{
	BYTE RxBuff[20000];
	int nRecvLen;

	memset(RxBuff, 0x00, sizeof(RxBuff));
	if((nRecvLen = RecvFrame(RxBuff)) == FALSE)
		return FALSE;

	if(RxBuff[0] != 0xD0 || RxBuff[1] != 0x00)                //Subheader
	{
		m_strErrMsg.Format(_T("RecvReadAck.. Subheader �̻�.."));
		return FALSE;
	}
	if(RxBuff[2] != 0x00 || RxBuff[3] != 0xFF)                // Network NO, PC NO
	{
		m_strErrMsg.Format(_T("RecvWriteAck.. Network or PC NO �̻�.."));
		return FALSE;
	}
	if(RxBuff[4] != 0xFF || RxBuff[5] != 0x03 || RxBuff[6] != 0x00)   // Specific value
	{
		m_strErrMsg.Format(_T("RecvWriteAck.. Specific Value �̻�.."));
		return FALSE;
	}

	WORD wErrNo = SwapToWord(RxBuff+9);
	if(wErrNo)
	{
		m_strErrMsg.Format(_T("RecvWriteAck.. ���� ����.. �����ڵ�[%d]"), wErrNo);
		return FALSE;
	}

	return TRUE;
}

int CMelsecEthernetSk::RecvFrame(BYTE *pRxBuff)
{
	DWORD dwLen = 0, nRealLen, nTotalLen = 0;

	m_bReceiving = TRUE;

	if(WaitForSingleObject(m_hRecvEvent, 2000) == WAIT_TIMEOUT)
	{
//		if(WaitForSingleObject(m_pSock->m_hEventRecv, 2000) == WAIT_TIMEOUT)
//		{
			m_strErrMsg.Format(_T("RecvFrame.. ���� ���ð� �ʰ� ����"));
			return FALSE;
//		}
	}

	if(IOCtl( FIONREAD, &dwLen ) == FALSE)
	{
		m_strErrMsg.Format(_T("RecvFrame.. IOCtl ���� [%s]"), CLib::GetSystemErrMsg());
		return FALSE;
	}

	if ((nRealLen = Receive(pRxBuff, dwLen)) != dwLen)
	{
		m_strErrMsg.Format(_T("RecvFrame.. Receive���� [%s]"), CLib::GetSystemErrMsg());
		return FALSE;
	}

	nTotalLen = nRealLen;

	if (dwLen < BINARY_HEADER_LEN)
	{
		if(WaitForSingleObject(m_hRecvEvent, 2000) == WAIT_TIMEOUT)	// 2000
		{
			m_strErrMsg.Format(_T("RecvFrame.. ���� ���ð� �ʰ� ����#2 [dwLen=%d]"), dwLen);
			return FALSE;
		}

		if(IOCtl( FIONREAD, &dwLen ) == FALSE)
		{
			m_strErrMsg.Format(_T("RecvFrame.. IOCtl ����#2 [%s]"), CLib::GetSystemErrMsg());
			return FALSE;
		}

		if ((nRealLen = Receive(pRxBuff+nRealLen, dwLen)) != dwLen)
		{
			m_strErrMsg.Format(_T("RecvFrame.. Receive����#2 [%s]"), CLib::GetSystemErrMsg());
			return FALSE;
		}

		nTotalLen += nRealLen;

		if(nRealLen <= BINARY_HEADER_LEN)
		{
			m_strErrMsg.Format(_T("RecvFrame.. ���� ������ ����[%d] �̻�"), nRealLen);
			return FALSE;
		}
	}

	m_bReceiving = FALSE;

	return nTotalLen;
}

WORD CMelsecEthernetSk::SwapToWord(BYTE *pSrc)
{
	return (WORD)(pSrc[1] << 8) | pSrc[0];
}

DWORD CMelsecEthernetSk::SwapToDWord(BYTE *pSrc)
{
	return (DWORD)(pSrc[3] << 24) | (pSrc[2] << 16) | (pSrc[1] << 8) | pSrc[0];
}

int CMelsecEthernetSk::GetDataLength(int nUnitType, WORD wLen)
{
	return (nUnitType == CMD_WORD_UNIT) ? (wLen*2) : ((wLen/2)+(wLen%2));
}

