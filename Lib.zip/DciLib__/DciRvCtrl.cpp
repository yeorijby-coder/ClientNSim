// DciRvCtrl.cpp: implementation of the CDciRvCtrl class.
//

#include "StdAfx.h"
#include "DciRvCtrl.h"


IMPLEMENT_SERIAL(CDciRvCtrl, CDciControl, DCI_SIRIALIZE_SCHEMA)

// CDciRvCtrl
CDciRvCtrl::CDciRvCtrl(void)
{
}


CDciRvCtrl::~CDciRvCtrl(void)
{
}

// CDciRvCtrl ��� �Լ�
void CDciRvCtrl::InitControl(CDciMaster* pDCI)
{
	CDciControl::InitControl(pDCI);
	m_nBgMode = TRANSPARENT;
	m_clrBgColor = ::GetSysColor(COLOR_BTNFACE);
	
	m_nType = enL2R;
	m_nForkType = enSingle;
	m_nForkPos = 1;
	m_clrFork = ::GetSysColor(COLOR_BTNFACE);
	m_clrFork1 = ::GetSysColor(COLOR_BTNFACE);
	m_clrFork2 = ::GetSysColor(COLOR_BTNFACE);
	m_clrWing = ::GetSysColor(COLOR_BTNFACE);
	m_clrRail = RGB(0,0,0);
	m_nIncrease = 0;
//	m_nCol		= 1;
//	m_nRow		= 1;
	m_nProd		= 0;
	m_nFontSize = 1;
	m_rcForkS.SetRect(0, 0, 0, 0);
	m_rcForkT.SetRect(0, 0, 0, 0);
	m_rcForkD.SetRect(0, 0, 0, 0);
}

int CDciRvCtrl::UpdatePropNames(CDciPropertyArray& properties)
{
	int i = CDciControl::UpdatePropNames(properties);

	properties.SetSize(enRvCtrlPropSize);
//	properties[i++].SetProperty(CDciProperty::PT_DEC, _T("col"));
//	properties[i++].SetProperty(CDciProperty::PT_DEC, _T("row"));
	properties[i++].SetProperty(CDciProperty::PT_DEC, _T("prod"));
	properties[i++].SetProperty(CDciProperty::PT_DEC, _T("forktype"));
	properties[i++].SetProperty(CDciProperty::PT_DEC, _T("type"));
	properties[i++].SetProperty(CDciProperty::PT_DEC, _T("forkpos"));
	properties[i++].SetProperty(CDciProperty::PT_COLOR, _T("forkcolor"));
	properties[i++].SetProperty(CDciProperty::PT_COLOR, _T("wingcolor"));
	properties[i++].SetProperty(CDciProperty::PT_COLOR, _T("railcolor"));
	properties[i++].SetProperty(CDciProperty::PT_DEC, _T("fontsize"));
	ASSERT(properties.GetSize() == i);

	return i;
}

int CDciRvCtrl::UpdatePropValues(CDciPropertyArray& properties, BOOL bSaveObject /* = TRUE */)
{
	int i = CDciControl::UpdatePropValues(properties, bSaveObject);

	if (bSaveObject)
	{
//		m_nCol		= CConvert::ToInt(properties[i++].m_strValue);
//		m_nRow		= CConvert::ToInt(properties[i++].m_strValue);
		m_nProd		= CConvert::ToInt(properties[i++].m_strValue);
		m_nForkType	= CConvert::ToInt(properties[i++].m_strValue);
		m_nType		= CConvert::ToInt(properties[i++].m_strValue);
		m_nForkPos	= CConvert::ToInt(properties[i++].m_strValue);
		m_clrFork	= CConvert::ToColor(properties[i++].m_strValue);
		m_clrFork2	= m_clrFork;
		m_clrWing	= CConvert::ToColor(properties[i++].m_strValue);
		m_clrRail	= CConvert::ToColor(properties[i++].m_strValue);
		m_nFontSize		= CConvert::ToInt(properties[i++].m_strValue);

	}
	else
	{
//		properties[i++].m_strValue.Format(_T("%d"), m_nCol);
//		properties[i++].m_strValue.Format(_T("%d"), m_nRow);
		properties[i++].m_strValue.Format(_T("%d"), m_nProd);
		properties[i++].m_strValue.Format(_T("%d"), m_nForkType);
		properties[i++].m_strValue.Format(_T("%d"), m_nType);
		properties[i++].m_strValue.Format(_T("%d"), m_nForkPos);
		properties[i++].m_strValue.Format(_T("%s"), CConvert::ToString(m_clrFork));
		properties[i++].m_strValue.Format(_T("%s"), CConvert::ToString(m_clrWing));
		properties[i++].m_strValue.Format(_T("%s"), CConvert::ToString(m_clrRail));
		properties[i++].m_strValue.Format(_T("%d"), m_nFontSize);
	}

	return i;
}
//===============================================================================================================================================
// ��ũ ��Ʈ�� ���� :	- ����Ÿ���ϰ�� - 
//===============================================================================================================================================
void CDciRvCtrl::UpdateControlHorizental(int nType , 
										 CPoint & ptRailS1, CPoint & ptRailS2, 
										 CRect & rcRailS1, CRect & rcRailS2, 
										 CRect & rcWingS1, CRect & rcWingS2, 
										 CRect & rcForkL1, CRect & rcForkL2,
										 CRect & rcForkS, CRect & rcForkT, CRect & rcForkD,
										 int nForkType /*= 0*/)
{
	if ( nType == enT2B || nType == enB2T)
		return;

	int nForkPos = 0, nForkSize = 1, nRailEndS = 4, nWingGapRatio = 10, nWingScaleRatio = 30;

//	if (nForkType == enDouble)
//		nRailEndS *= 2;

	rcRailS1.SetRect(ptRailS1.x, ptRailS1.y - nRailEndS/2, ptRailS1.x + nRailEndS, ptRailS1.y + nRailEndS/2);
	rcRailS2.SetRect(ptRailS2.x, ptRailS2.y - nRailEndS/2, ptRailS2.x - nRailEndS, ptRailS2.y + nRailEndS/2);

	nForkSize = abs(m_rcControlL.Height()) ? abs(m_rcControlL.Height()) : 1;
	if (m_nForkPos <= 0) nForkPos = 0;
	else if (m_nForkPos >= abs(m_rcControlL.Width()/nForkSize)) nForkPos = abs(m_rcControlL.Width())/nForkSize - 1;
	else nForkPos = m_nForkPos;

	if (nType == enL2R)
	{
		rcForkL1.left = m_rcControlL.left + nForkPos*nForkSize;
		rcForkL1.top = m_rcControlL.top;
		rcForkL1.right = m_rcControlL.left + (nForkPos+1)*nForkSize;
		rcForkL1.bottom = m_rcControlL.bottom;
		m_rcForkS = rcForkS = m_pDCI->ConvertRectS(rcForkL1);

		rcWingS1.left = rcForkS.left - rcForkS.Width()*nWingGapRatio/100 - rcForkS.Width()*nWingScaleRatio/100;
		rcWingS1.top = rcForkS.top + rcForkS.Height()/2 - rcForkS.Height()*nWingScaleRatio/100;
		rcWingS1.right = rcForkS.left - rcForkS.Width()*nWingGapRatio/100;
		rcWingS1.bottom = rcForkS.top + rcForkS.Height()/2 + rcForkS.Height()*nWingScaleRatio/100;

		if (nForkType == enSingle)
		{
		rcWingS2.left = rcForkS.right + rcForkS.Width()*nWingGapRatio/100;
		rcWingS2.top = rcForkS.top + rcForkS.Height()/2 - rcForkS.Height()*nWingScaleRatio/100;
		rcWingS2.right = rcForkS.right + rcForkS.Width()*nWingGapRatio/100 + rcForkS.Width()*nWingScaleRatio/100;
		rcWingS2.bottom = rcForkS.top + rcForkS.Height()/2 + rcForkS.Height()*nWingScaleRatio/100;
		}
		else if (nForkType == enTwin)
		{
			rcForkL2.left = m_rcControlL.left + (nForkPos+1)*nForkSize;
			rcForkL2.top = m_rcControlL.top;
			rcForkL2.right = m_rcControlL.left + (nForkPos+2)*nForkSize;
			rcForkL2.bottom = m_rcControlL.bottom;
			m_rcForkT = rcForkT = m_pDCI->ConvertRectS(rcForkL2);

			rcWingS2.left = rcForkT.right + rcForkT.Width()*nWingGapRatio/100;
			rcWingS2.top = rcForkT.top + rcForkT.Height()/2 - rcForkT.Height()*nWingScaleRatio/100;
			rcWingS2.right = rcForkT.right + rcForkT.Width()*nWingGapRatio/100 + rcForkT.Width()*nWingScaleRatio/100;
			rcWingS2.bottom = rcForkT.top + rcForkT.Height()/2 + rcForkT.Height()*nWingScaleRatio/100;
		}
		else if (nForkType == enDouble)
		{
			// ��ũ����� ������ �پ�� ��!!
			nForkSize = nForkSize/2;

			// ������ ������ �ٿ��� ��! 
			nRailEndS /= 2;
			rcRailS1.SetRect(ptRailS1.x, ptRailS1.y - nRailEndS/2, ptRailS1.x + nRailEndS, ptRailS1.y + nRailEndS/2);
			rcRailS2.SetRect(ptRailS2.x, ptRailS2.y - nRailEndS/2, ptRailS2.x - nRailEndS, ptRailS2.y + nRailEndS/2);

			// ��ũ #1 ����
			rcForkL1.left	= m_rcControlL.left			+  (nForkPos		* nForkSize);
			rcForkL1.top	= m_rcControlL.top;
			rcForkL1.right	= m_rcControlL.left			+ ((nForkPos + 1)	* nForkSize);
			rcForkL1.bottom = m_rcControlL.top								- nForkSize;
			m_rcForkS = rcForkS = m_pDCI->ConvertRectS(rcForkL1);

			// �� #1 ����
			rcWingS1.left	= rcForkS.left		- rcForkS.Width()*nWingGapRatio/100 - rcForkS.Width()*nWingScaleRatio/100;
			rcWingS1.top	= rcForkS.bottom	+ rcForkS.Height()/2				+ rcForkS.Height()*nWingScaleRatio/100;
			rcWingS1.right	= rcForkS.left		- rcForkS.Width()*nWingGapRatio/100;
			rcWingS1.bottom = rcForkS.bottom	- rcForkS.Height()/2				- rcForkS.Height()*nWingScaleRatio/100;

			// �� #2 ����
			rcWingS2.left	= rcForkS.right		+ rcForkS.Width()*nWingGapRatio/100;
			rcWingS2.top	= rcForkS.bottom	+ rcForkS.Height()/2				+ rcForkS.Height()*nWingScaleRatio/100;
			rcWingS2.right	= rcForkS.right		+ rcForkS.Width()*nWingGapRatio/100 + rcForkS.Width()*nWingScaleRatio/100;
			rcWingS2.bottom = rcForkS.bottom	- rcForkS.Height()/2				- rcForkS.Height()*nWingScaleRatio/100;

			// ��ũ #2 ����
			rcForkL2.left	= m_rcControlL.left		+  (nForkPos		* nForkSize);
			rcForkL2.top	= m_rcControlL.bottom						+ nForkSize;
			rcForkL2.right	= m_rcControlL.left		+ ((nForkPos + 1)	* nForkSize);
			rcForkL2.bottom = m_rcControlL.bottom;	
			m_rcForkD = rcForkD = m_pDCI->ConvertRectS(rcForkL2);		
		}
	}
	else //if (nType == enR2L)
	{
		rcForkL1.left = m_rcControlL.right - (nForkPos+1)*nForkSize;		
		rcForkL1.top = m_rcControlL.top;									
		rcForkL1.right = m_rcControlL.right - nForkPos*nForkSize;			
		rcForkL1.bottom = m_rcControlL.bottom;								
		m_rcForkS = rcForkS = m_pDCI->ConvertRectS(rcForkL1);				

		rcWingS1.left = rcForkS.left - rcForkS.Width()*nWingGapRatio/100 - rcForkS.Width()*nWingScaleRatio/100;
		rcWingS1.top = rcForkS.top + rcForkS.Height()/2 - rcForkS.Height()*nWingScaleRatio/100;
		rcWingS1.right = rcForkS.left - rcForkS.Width()*nWingGapRatio/100;
		rcWingS1.bottom = rcForkS.top + rcForkS.Height()/2 + rcForkS.Height()*nWingScaleRatio/100;

		if (nForkType == enSingle)
		{
		rcWingS2.left = rcForkS.right + rcForkS.Width()*nWingGapRatio/100;
		rcWingS2.top = rcForkS.top + rcForkS.Height()/2 - rcForkS.Height()*nWingScaleRatio/100;
		rcWingS2.right = rcForkS.right + rcForkS.Width()*nWingGapRatio/100 + rcForkS.Width()*nWingScaleRatio/100;
		rcWingS2.bottom = rcForkS.top + rcForkS.Height()/2 + rcForkS.Height()*nWingScaleRatio/100;
		}
		else if (nForkType == enTwin)
		{
			rcForkL2.left = m_rcControlL.right - (nForkPos+2)*nForkSize;	
			rcForkL2.top = m_rcControlL.top;								
			rcForkL2.right = m_rcControlL.right - (nForkPos+1)*nForkSize;	
			rcForkL2.bottom = m_rcControlL.bottom;							
			m_rcForkT = rcForkT = m_pDCI->ConvertRectS(rcForkL2);			

			rcWingS1.left = rcForkT.left - rcForkT.Width()*nWingGapRatio/100 - rcForkT.Width()*nWingScaleRatio/100;
			rcWingS1.top = rcForkT.top + rcForkT.Height()/2 - rcForkT.Height()*nWingScaleRatio/100;
			rcWingS1.right = rcForkT.left - rcForkT.Width()*nWingGapRatio/100;
			rcWingS1.bottom = rcForkT.top + rcForkT.Height()/2 + rcForkT.Height()*nWingScaleRatio/100;
		}
		else if (nForkType == enDouble)
		{
			// ��ũ����� ������ �پ�� ��!!
			nForkSize = nForkSize/2;

			// ������ ������ �ٿ��� ��! 
			nRailEndS /= 2;
			rcRailS1.SetRect(ptRailS1.x, ptRailS1.y - nRailEndS/2, ptRailS1.x + nRailEndS, ptRailS1.y + nRailEndS/2);
			rcRailS2.SetRect(ptRailS2.x, ptRailS2.y - nRailEndS/2, ptRailS2.x - nRailEndS, ptRailS2.y + nRailEndS/2);

	
//			// ��ũ #1 ����
//			rcForkL1.left	= m_rcControlL.right		- (nForkPos + 1)	* nForkSize;
//			rcForkL1.top	= m_rcControlL.top;
//			rcForkL1.right	= m_rcControlL.right		-  nForkPos			* nForkSize;
//			rcForkL1.bottom = m_rcControlL.top								- nForkSize;
//			m_rcForkS = rcForkS = m_pDCI->ConvertRectS(rcForkL1);
//			// ��ũ #1 ����
			rcForkL1.left	= m_rcControlL.right	- (nForkPos + 1)	* nForkSize;
			rcForkL1.top	= m_rcControlL.bottom						+ nForkSize;
			rcForkL1.right	= m_rcControlL.right	-  nForkPos			* nForkSize;
			rcForkL1.bottom = m_rcControlL.bottom;	
			m_rcForkS = rcForkS = m_pDCI->ConvertRectS(rcForkL1);

//			// �� #1 ����
//			rcWingS1.left	= rcForkS.left		- rcForkS.Width()*nWingGapRatio/100 - rcForkS.Width()*nWingScaleRatio/100;
//			rcWingS1.top	= rcForkS.bottom	+ rcForkS.Height()/2				+ rcForkS.Height()*nWingScaleRatio/100;
//			rcWingS1.right	= rcForkS.left		- rcForkS.Width()*nWingGapRatio/100;
//			rcWingS1.bottom = rcForkS.bottom	- rcForkS.Height()/2				- rcForkS.Height()*nWingScaleRatio/100;
//
//			// �� #2 ����
//			rcWingS2.left	= rcForkS.right		+ rcForkS.Width()*nWingGapRatio/100;
//			rcWingS2.top	= rcForkS.bottom	+ rcForkS.Height()/2				+ rcForkS.Height()*nWingScaleRatio/100;
//			rcWingS2.right	= rcForkS.right		+ rcForkS.Width()*nWingGapRatio/100 + rcForkS.Width()*nWingScaleRatio/100;
//			rcWingS2.bottom = rcForkS.bottom	- rcForkS.Height()/2				- rcForkS.Height()*nWingScaleRatio/100;
//
//			// ��ũ #2 ����
//			rcForkL2.left	= m_rcControlL.right	- (nForkPos + 1)	* nForkSize;
//			rcForkL2.top	= m_rcControlL.bottom						+ nForkSize;
//			rcForkL2.right	= m_rcControlL.right	-  nForkPos			* nForkSize;
//			rcForkL2.bottom = m_rcControlL.bottom;	
//			m_rcForkD = rcForkD = m_pDCI->ConvertRectS(rcForkL2);		
//			// ��ũ #2 ����
			rcForkL2.left	= m_rcControlL.right		- (nForkPos + 1)	* nForkSize;
			rcForkL2.top	= m_rcControlL.top;
			rcForkL2.right	= m_rcControlL.right		-  nForkPos			* nForkSize;
			rcForkL2.bottom = m_rcControlL.top								- nForkSize;
			m_rcForkD = rcForkD = m_pDCI->ConvertRectS(rcForkL2);		

			// �� #1 ����
			rcWingS1.left	= rcForkD.left		- rcForkD.Width()*nWingGapRatio/100 - rcForkD.Width()*nWingScaleRatio/100;
			rcWingS1.top	= rcForkD.bottom	+ rcForkD.Height()/2				+ rcForkD.Height()*nWingScaleRatio/100;
			rcWingS1.right	= rcForkD.left		- rcForkD.Width()*nWingGapRatio/100;
			rcWingS1.bottom = rcForkD.bottom	- rcForkD.Height()/2				- rcForkD.Height()*nWingScaleRatio/100;

			// �� #2 ����
			rcWingS2.left	= rcForkD.right		+ rcForkD.Width()*nWingGapRatio/100;
			rcWingS2.top	= rcForkD.bottom	+ rcForkD.Height()/2				+ rcForkD.Height()*nWingScaleRatio/100;
			rcWingS2.right	= rcForkD.right		+ rcForkD.Width()*nWingGapRatio/100 + rcForkD.Width()*nWingScaleRatio/100;
			rcWingS2.bottom = rcForkD.bottom	- rcForkD.Height()/2				- rcForkD.Height()*nWingScaleRatio/100;




		}
	}
}

void CDciRvCtrl::UpdateControlVertical(	int nType ,
									    CPoint & ptRailS1, CPoint & ptRailS2, 
										CRect & rcRailS1, CRect & rcRailS2, 
										CRect & rcWingS1, CRect & rcWingS2, 
										CRect & rcForkL1, CRect & rcForkL2,
										CRect & rcForkS, CRect & rcForkT, CRect & rcForkD,
										int nForkType /*= 0*/)
{

	if ( nType == enL2R || nType == enR2L)
		return;

	int nForkPos = 0, nForkSize = 1, nRailEndS = 4, nWingGapRatio = 10, nWingScaleRatio = 30;

	rcRailS1.SetRect(ptRailS1.x - nRailEndS/2, ptRailS1.y, ptRailS1.x + nRailEndS/2, ptRailS1.y + nRailEndS);
	rcRailS2.SetRect(ptRailS2.x - nRailEndS/2, ptRailS2.y - nRailEndS, ptRailS2.x + nRailEndS/2, ptRailS2.y);

	nForkSize = abs(m_rcControlL.Width()) ? abs(m_rcControlL.Width()) : 1;
	if (m_nForkPos <= 0) nForkPos = 0;
	else if (m_nForkPos >= abs(m_rcControlL.Height()/nForkSize)) nForkPos = abs(m_rcControlL.Height())/nForkSize - 1;
	else nForkPos = m_nForkPos;

	if (nType == enT2B)
	{
		rcForkL1.left = m_rcControlL.left;
		rcForkL1.top = m_rcControlL.top - nForkPos*nForkSize;
		rcForkL1.right = m_rcControlL.right;
		rcForkL1.bottom = m_rcControlL.top - (nForkPos+1)*nForkSize;
		m_rcForkS = rcForkS = m_pDCI->ConvertRectS(rcForkL1);

		rcWingS1.left = rcForkS.left + rcForkS.Width()/2 - rcForkS.Width()*nWingScaleRatio/100;
		rcWingS1.top = rcForkS.top - rcForkS.Height()*nWingGapRatio/100 - rcForkS.Height()*nWingScaleRatio/100;
		rcWingS1.right = rcForkS.left + rcForkS.Width()/2 + rcForkS.Width()*nWingScaleRatio/100;
		rcWingS1.bottom = rcForkS.top - rcForkS.Height()*nWingGapRatio/100;

		rcWingS2.left = rcForkS.left + rcForkS.Width()/2 - rcForkS.Width()*nWingScaleRatio/100;
		rcWingS2.top = rcForkS.bottom + rcForkS.Height()*nWingGapRatio/100;
		rcWingS2.right = rcForkS.left + rcForkS.Width()/2 + rcForkS.Width()*nWingScaleRatio/100;
		rcWingS2.bottom = rcForkS.bottom + rcForkS.Height()*nWingGapRatio/100 + rcForkS.Height()*nWingScaleRatio/100;

		if (nForkType == enTwin)
		{
			rcForkL2.left = m_rcControlL.left;
			rcForkL2.top = m_rcControlL.top - (nForkPos+1)*nForkSize;
			rcForkL2.right = m_rcControlL.right;
			rcForkL2.bottom = m_rcControlL.top - (nForkPos+2)*nForkSize;
			m_rcForkT = rcForkT = m_pDCI->ConvertRectS(rcForkL2);

			rcWingS2.left = rcForkT.left + rcForkT.Width()/2 - rcForkT.Width()*nWingScaleRatio/100;
			rcWingS2.top = rcForkT.bottom + rcForkT.Height()*nWingGapRatio/100;
			rcWingS2.right = rcForkT.left + rcForkT.Width()/2 + rcForkT.Width()*nWingScaleRatio/100;
			rcWingS2.bottom = rcForkT.bottom + rcForkT.Height()*nWingGapRatio/100 + rcForkT.Height()*nWingScaleRatio/100;
		}
		else if (nForkType == enDouble)
		{
			// ��ũ����� ������ �پ�� ��!!
			nForkSize = nForkSize/2;

			// ������ ������ �ٿ��� ��! 
			nRailEndS /= 2;
			rcRailS1.SetRect(ptRailS1.x - nRailEndS/2, ptRailS1.y, ptRailS1.x + nRailEndS/2, ptRailS1.y + nRailEndS);
			rcRailS2.SetRect(ptRailS2.x - nRailEndS/2, ptRailS2.y - nRailEndS, ptRailS2.x + nRailEndS/2, ptRailS2.y);
	
			// ��ũ #1 ����
			rcForkL1.left	= m_rcControlL.left;
			rcForkL1.top	= m_rcControlL.top			- (nForkPos + 1)	* nForkSize;
			rcForkL1.right	= m_rcControlL.right							- nForkSize;
			rcForkL1.bottom = m_rcControlL.top			-  nForkPos			* nForkSize;
			m_rcForkS = rcForkS = m_pDCI->ConvertRectS(rcForkL1);

			// �� #1 ����
			rcWingS1.left	= rcForkS.right		- rcForkS.Width()/2						- rcForkS.Width()*nWingScaleRatio/100;
			rcWingS1.top	= rcForkS.top		- rcForkS.Height()*nWingGapRatio/100	- rcForkS.Height()*nWingScaleRatio/100;
			rcWingS1.right	= rcForkS.right		+ rcForkS.Width()/2						+ rcForkS.Width()*nWingScaleRatio/100;
			rcWingS1.bottom = rcForkS.top		- rcForkS.Height()*nWingGapRatio/100;
			
			// �� #2 ����
			rcWingS2.left	= rcForkS.right		- rcForkS.Width()/2						- rcForkS.Width()*nWingScaleRatio/100;
			rcWingS2.top	= rcForkS.bottom	+ rcForkS.Height()*nWingGapRatio/100;
			rcWingS2.right	= rcForkS.right		+ rcForkS.Width()/2						+ rcForkS.Width()*nWingScaleRatio/100;
			rcWingS2.bottom = rcForkS.bottom	+ rcForkS.Height()*nWingGapRatio/100	+ rcForkS.Height()*nWingScaleRatio/100;

			// ��ũ #2 ����
			rcForkL2.left	= m_rcControlL.left							+ nForkSize;
			rcForkL2.top	= m_rcControlL.top		- (nForkPos + 1)	* nForkSize;
			rcForkL2.right	= m_rcControlL.right;
			rcForkL2.bottom = m_rcControlL.top		-  nForkPos			* nForkSize;	
			m_rcForkD = rcForkD = m_pDCI->ConvertRectS(rcForkL2);		
		}
	}
	else //if (nType == enB2T)
	{
		rcForkL1.left = m_rcControlL.left;
		rcForkL1.top = m_rcControlL.bottom + (nForkPos+1)*nForkSize;
		rcForkL1.right = m_rcControlL.right;
		rcForkL1.bottom = m_rcControlL.bottom + nForkPos*nForkSize;
		m_rcForkS = rcForkS = m_pDCI->ConvertRectS(rcForkL1);

		rcWingS1.left = rcForkS.left + rcForkS.Width()/2 - rcForkS.Width()*nWingScaleRatio/100;
		rcWingS1.top = rcForkS.top - rcForkS.Height()*nWingGapRatio/100 - rcForkS.Height()*nWingScaleRatio/100;
		rcWingS1.right = rcForkS.left + rcForkS.Width()/2 + rcForkS.Width()*nWingScaleRatio/100;
		rcWingS1.bottom = rcForkS.top - rcForkS.Height()*nWingGapRatio/100;

		rcWingS2.left = rcForkS.left + rcForkS.Width()/2 - rcForkS.Width()*nWingScaleRatio/100;
		rcWingS2.top = rcForkS.bottom + rcForkS.Height()*nWingGapRatio/100;
		rcWingS2.right = rcForkS.left + rcForkS.Width()/2 + rcForkS.Width()*nWingScaleRatio/100;
		rcWingS2.bottom = rcForkS.bottom + rcForkS.Height()*nWingGapRatio/100 + rcForkS.Height()*nWingScaleRatio/100;

		if (nForkType == enTwin)
		{
			rcForkL2.left = m_rcControlL.left;
			rcForkL2.top = m_rcControlL.bottom + (nForkPos+2)*nForkSize;
			rcForkL2.right = m_rcControlL.right;
			rcForkL2.bottom = m_rcControlL.bottom + (nForkPos+1)*nForkSize;
			m_rcForkT = rcForkT = m_pDCI->ConvertRectS(rcForkL2);

			rcWingS1.left = rcForkT.left + rcForkT.Width()/2 - rcForkT.Width()*nWingScaleRatio/100;
			rcWingS1.top = rcForkT.top - rcForkT.Height()*nWingGapRatio/100 - rcForkT.Height()*nWingScaleRatio/100;
			rcWingS1.right = rcForkT.left + rcForkT.Width()/2 + rcForkT.Width()*nWingScaleRatio/100;
			rcWingS1.bottom = rcForkT.top - rcForkT.Height()*nWingGapRatio/100;
		}
		else if (nForkType == enDouble)
		{
			// ��ũ����� ������ �پ�� ��!!
			nForkSize = nForkSize/2;

			// ������ ������ �ٿ��� ��! 
			nRailEndS /= 2;
			rcRailS1.SetRect(ptRailS1.x - nRailEndS/2, ptRailS1.y, ptRailS1.x + nRailEndS/2, ptRailS1.y + nRailEndS);
			rcRailS2.SetRect(ptRailS2.x - nRailEndS/2, ptRailS2.y - nRailEndS, ptRailS2.x + nRailEndS/2, ptRailS2.y);
	
			// ��ũ #1 ����
			rcForkL1.left = m_rcControlL.left;
			rcForkL1.top = m_rcControlL.bottom + (nForkPos+1)*nForkSize;
			rcForkL1.right = m_rcControlL.right - nForkSize;
			rcForkL1.bottom = m_rcControlL.bottom + nForkPos*nForkSize;
			m_rcForkS = rcForkS = m_pDCI->ConvertRectS(rcForkL1);

			// �� #1 ����
			rcWingS1.left	= rcForkS.right		- rcForkS.Width()/2						- rcForkS.Width()*nWingScaleRatio/100;
			rcWingS1.top	= rcForkS.top		- rcForkS.Height()*nWingGapRatio/100	- rcForkS.Height()*nWingScaleRatio/100;
			rcWingS1.right	= rcForkS.right		+ rcForkS.Width()/2						+ rcForkS.Width()*nWingScaleRatio/100;
			rcWingS1.bottom = rcForkS.top		- rcForkS.Height()*nWingGapRatio/100;
			
			// �� #2 ����
			rcWingS2.left	= rcForkS.right		- rcForkS.Width()/2						- rcForkS.Width()*nWingScaleRatio/100;
			rcWingS2.top	= rcForkS.bottom	+ rcForkS.Height()*nWingGapRatio/100;
			rcWingS2.right	= rcForkS.right		+ rcForkS.Width()/2						+ rcForkS.Width()*nWingScaleRatio/100;
			rcWingS2.bottom = rcForkS.bottom	+ rcForkS.Height()*nWingGapRatio/100	+ rcForkS.Height()*nWingScaleRatio/100;

			// ��ũ #2 ����
			rcForkL2.left	= m_rcControlL.left  + nForkSize;
			rcForkL2.top	= m_rcControlL.bottom	+ (nForkPos+1)	* nForkSize;
			rcForkL2.right	= m_rcControlL.right;//	+ nForkSize;
			rcForkL2.bottom = m_rcControlL.bottom	+ nForkPos		* nForkSize;	
			m_rcForkD = rcForkD = m_pDCI->ConvertRectS(rcForkL2);		
		}
	}
}
void CDciRvCtrl::UpdateControl(CDC* pDC)
{
	if (!m_bVisible)
		return;

	try
	{
		CPoint ptRailS1, ptRailS2;					// ���ϳ��� ����Ʈ???
		CRect rcControlS;							// ��Ʈ�� ��鷯??
		CRect rcRailS1, rcRailS2;					// ���� ��鷯???		// S1:����(�Ʒ�), S2:����(��)
		CRect rcWingS1, rcWingS2;					// �� ��鷯???			// S1:����(�Ʒ�), S2:����(��)
		CRect rcForkL1, rcForkL2;					// ��ũ �ӽ� ��鷯???	// L1:Single��,   L2:Twin, Double��		
		CRect rcForkS, rcForkT, rcForkD;			// ��ũ ��鷯???		// S :Single��,   T :Twin��		D :Double��
		CRect rcIntersect;

//		int nForkPos = 0, nForkSize = 1, nRailEndS = 4, nWingGapRatio = 10, nWingScaleRatio = 30;
		rcControlS = m_pDCI->ConvertRectS(m_rcControlL);


		LOGFONT m_logfont;
		CFont m_font ;
		CFont * pOldFont;

		int nSize = rcControlS.Height();
		if (rcControlS.Height() > rcControlS.Width())
			nSize = rcControlS.Width();

		nSize = (nSize / 2) -  (nSize / 10);

		HDC hDC;
		hDC = pDC->m_hDC;
		hDC = pDC->GetSafeHdc();
		memset(&m_logfont, 0, sizeof(LOGFONT));
		m_logfont.lfQuality = PROOF_QUALITY;
	//	m_logfont.lfHeight = m_nFontSize;
		m_logfont.lfHeight = nSize;//long((-MulDiv(m_nFontSize, GetDeviceCaps(hDC, LOGPIXELSY), 72 )) / m_pDCI->GetScale()); //nSize;//
		m_logfont.lfWeight = FW_BOLD;
		lstrcpy(m_logfont.lfFaceName, _T("Arial"));
		m_font.CreateFontIndirect(&m_logfont);
		pOldFont = pDC->SelectObject(&m_font);

		//pDC->DrawText(m_strText, rcControlS, DT_SINGLELINE|DT_CENTER|DT_VCENTER);

		switch (m_nForkType)
		{
		case enSingle:
			{
				switch (m_nType)
				{
				case enL2R:
				case enR2L:
					{
						// ���ϳ��� �� ǥ���ϱ�
						ptRailS1.x = rcControlS.left;
						ptRailS1.y = rcControlS.top + abs(rcControlS.Height()/2);
						ptRailS2.x = rcControlS.right;
						ptRailS2.y = rcControlS.top + abs(rcControlS.Height()/2);

						UpdateControlHorizental(m_nType, 
												ptRailS1, ptRailS2, 
												rcRailS1, rcRailS2, 
												rcWingS1, rcWingS2, 
												rcForkL1, rcForkL2,
												rcForkS, rcForkT, rcForkD);
					}
					break;
				case enT2B:
				case enB2T:
					{
						// ���ϳ��� �� ǥ���ϱ�
						ptRailS1.x = rcControlS.left + abs(rcControlS.Width()/2);
						ptRailS1.y = rcControlS.top;
						ptRailS2.x = rcControlS.left + abs(rcControlS.Width()/2);
						ptRailS2.y = rcControlS.bottom;

						UpdateControlVertical(	m_nType, 
												ptRailS1, ptRailS2, 
												rcRailS1, rcRailS2, 
												rcWingS1, rcWingS2, 
												rcForkL1, rcForkL2,
												rcForkS, rcForkT, rcForkD);
					}
					break;
				}
			}
			break;
		case enTwin:
			{
				switch (m_nType)
				{
				case enL2R:
				case enR2L:
					{
						// ���ϳ��� �� ǥ���ϱ�
						ptRailS1.x = rcControlS.left;
						ptRailS1.y = rcControlS.top + abs(rcControlS.Height()/2);
						ptRailS2.x = rcControlS.right;
						ptRailS2.y = rcControlS.top + abs(rcControlS.Height()/2);

						UpdateControlHorizental(m_nType, 
												ptRailS1, ptRailS2, 
												rcRailS1, rcRailS2, 
												rcWingS1, rcWingS2, 
												rcForkL1, rcForkL2,
												rcForkS, rcForkT, rcForkD, 
												enTwin);
					}
					break;
				case enT2B:
				case enB2T:
					{
						// ���ϳ��� �� ǥ���ϱ�
						ptRailS1.x = rcControlS.left + abs(rcControlS.Width()/2);
						ptRailS1.y = rcControlS.top;
						ptRailS2.x = rcControlS.left + abs(rcControlS.Width()/2);
						ptRailS2.y = rcControlS.bottom;

						UpdateControlVertical(	m_nType, 
												ptRailS1, ptRailS2, 
												rcRailS1, rcRailS2, 
												rcWingS1, rcWingS2, 
												rcForkL1, rcForkL2,
												rcForkS, rcForkT, rcForkD, 
												enTwin);
					}
				case enTypeSize:
					{
						// ���ϳ��� �� ǥ���ϱ�
						ptRailS1.x = rcControlS.left + abs(rcControlS.Width()/2);
						ptRailS1.y = rcControlS.top;
						ptRailS2.x = rcControlS.left + abs(rcControlS.Width()/2);
						ptRailS2.y = rcControlS.bottom;

						UpdateControlVertical(	m_nType, 
												ptRailS1, ptRailS2, 
												rcRailS1, rcRailS2, 
												rcWingS1, rcWingS2, 
												rcForkL1, rcForkL2,
												rcForkS, rcForkT, rcForkD, 
												enTwin);						




					}
					break;
				}
			}
			break;
		case enDouble:
			{
				switch (m_nType)
				{
				case enL2R:
				case enR2L:
					{
						// ���� Ÿ���϶��� Top�� �÷��� ��!		m_rcControlL
//						if (m_nIncrease == 0)
//						{
//							int nForkSize = abs(m_rcControlL.Height()) ? abs(m_rcControlL.Height()) : 1;
//							m_rcControlL.top = abs(m_rcControlL.top) + abs(rcControlS.Height()/2);
//
//							m_nIncrease++;
//						}

						CString strTemp;
						strTemp.Format(_T("Bottom = %d \nTop = %d \nLeft = %d \nRight = %d "), 
							m_rcControlL.bottom, m_rcControlL.top, m_rcControlL.left, m_rcControlL.right);
//						AfxMessageBox(strTemp);

						// ���ϳ��� �� ǥ���ϱ�
						ptRailS1.x = rcControlS.left;
						ptRailS1.y = rcControlS.top + abs(rcControlS.Height()/2);		// ������ġ �̵�
						ptRailS2.x = rcControlS.right;
						ptRailS2.y = rcControlS.top + abs(rcControlS.Height()/2);		// ������ġ �̵�

						UpdateControlHorizental(m_nType, 
												ptRailS1, ptRailS2, 
												rcRailS1, rcRailS2, 
												rcWingS1, rcWingS2, 
												rcForkL1, rcForkL2,
												rcForkS, rcForkT, rcForkD, 
												enDouble);
					}
					break;
				case enT2B:
				case enB2T:
					{
						// ���� Ÿ���϶��� Right�� �÷��� ��!
//						if (m_nIncrease == 0)
//						{
//							int nForkSize = abs(m_rcControlL.Width()) ? abs(m_rcControlL.Width()) : 1;
//							m_rcControlL.right = m_rcControlL.right + rcControlS.Width();
//
//							m_nIncrease++;
//						}

						// ���ϳ��� �� ǥ���ϱ�
						ptRailS1.x = rcControlS.left + abs(rcControlS.Width()/2);		// ������ġ �̵�
						ptRailS1.y = rcControlS.top;
						ptRailS2.x = rcControlS.left + abs(rcControlS.Width()/2);		// ������ġ �̵�
						ptRailS2.y = rcControlS.bottom;

						UpdateControlVertical(	m_nType, 
												ptRailS1, ptRailS2, 
												rcRailS1, rcRailS2, 
												rcWingS1, rcWingS2, 
												rcForkL1, rcForkL2,
												rcForkS, rcForkT, rcForkD, 
												enDouble);
					}
					break;
				}
			}
			break;
		}

		CPen* pOldPen = NULL;
		CPen penRail(PS_SOLID, 1, m_clrRail);

		CBrush* pOldBrush = NULL;
		CBrush bgBrush(m_clrBgColor), wingBrush(m_clrWing), railBrush(m_clrRail);

		int nOldMode = pDC->SetBkMode(m_nFgMode);
		int nOldFgColor = pDC->SetTextColor(m_clrFgColor);

		/////////////////////////////////////////////////////////////////////////////////////////

		if (m_nBgMode == TRANSPARENT)
			pOldBrush = (CBrush*)pDC->SelectStockObject(NULL_BRUSH);
		else
			pOldBrush = pDC->SelectObject(&bgBrush);
		pOldPen = (CPen*) pDC->SelectStockObject(NULL_PEN);
		pDC->Rectangle(rcControlS);

		/////////////////////////////////////////////////////////////////////////////////////////

		pDC->SelectObject(&penRail);
		pDC->MoveTo(ptRailS1);
		pDC->LineTo(ptRailS2);

		pDC->SelectObject(&railBrush);
		pDC->Ellipse(rcRailS1);
		pDC->Ellipse(rcRailS2);

		/////////////////////////////////////////////////////////////////////////////////////////

		m_pDCI->DrawButton(pDC, rcForkL1, m_clrFork, m_bClick);
		m_pDCI->DrawText(pDC, rcForkL1, m_strText, m_clrFgColor);

//		if (m_nForkType == enTwin)
		if (m_nForkType != enSingle)
		{
			m_pDCI->DrawButton(pDC, rcForkL2, m_clrFork2, m_bClick);
			m_pDCI->DrawText(pDC, rcForkL2, m_strText, m_clrFgColor);
		}

//		if (m_nForkType == enDouble)
//		{
//			m_pDCI->DrawButton(pDC, rcForkL3, m_clrFork, m_bClick);
//			m_pDCI->DrawText(pDC, rcForkL3, m_strText, m_clrFgColor);
//		}

		rcIntersect.IntersectRect(rcWingS1, rcControlS);
		if (rcWingS1.EqualRect(rcIntersect))
		{
			pDC->FillSolidRect(rcWingS1, m_clrWing);
			pDC->Draw3dRect(rcWingS1, RGB(255,255,255), RGB(0,0,0));
		}

		rcIntersect.IntersectRect(rcWingS2, rcControlS);
		if (rcWingS2.EqualRect(rcIntersect))
		{
			pDC->FillSolidRect(rcWingS2, m_clrWing);
			pDC->Draw3dRect(rcWingS2, RGB(255,255,255), RGB(0,0,0));
		}

		// ���� ��ũ �϶��� �ϳ��� �׸��带 �Ѿ�ϱ�... IntersectRect�� EqualRect�� üũ���� �ʴ´�.
		// �Ʒ��� ������ ������ ���� ��ũ�϶� ���� ǥ������ ����!!
		if (m_nForkType == enDouble)
		{
			pDC->FillSolidRect(rcWingS1, m_clrWing);
			pDC->Draw3dRect(rcWingS1, RGB(255,255,255), RGB(0,0,0));
		
			pDC->FillSolidRect(rcWingS2, m_clrWing);
			pDC->Draw3dRect(rcWingS2, RGB(255,255,255), RGB(0,0,0));
		}

		/////////////////////////////////////////////////////////////////////////////////////////
//==========================================================================================================================================================
//		// ȭ�� ���� ǥ�� - CScInfo::InvokeControl(), CScInfo::InvokeControl()���� 
//		//					m_pControl->m_clrWing = GetPostColor(); �� �κ� �ּ� ó���Ұ�!!
//==========================================================================================================================================================
		int g = 2, s = 4;
		CRect rcTemp;
		// 1�� ��ũ
		if (m_nProd == 1)
		{
			rcTemp = m_pDCI->ConvertRectS(rcForkL1);
			IndicateProdSensor(pDC, rcTemp, g, s, 0x000000);
		}
		// 2�� ��ũ
		else if (m_nProd == 2)
		{
			rcTemp = m_pDCI->ConvertRectS(rcForkL2);
			IndicateProdSensor(pDC, rcTemp, g, s, 0x000000);
		}
		// ȭ�� 2�� ���ð���
		else if (m_nProd == 3)
		{
			// 1�� ��ũ
			rcTemp = m_pDCI->ConvertRectS(rcForkL1);
			IndicateProdSensor(pDC, rcTemp, g, s, 0x000000);

			// 2�� ��ũ
			rcTemp = m_pDCI->ConvertRectS(rcForkL2);
			IndicateProdSensor(pDC, rcTemp, g, s, 0x000000);
		}
//----------------------------------------------------------------------------------------------------------------------------------------------------------



		pDC->SelectObject(pOldBrush);
		pDC->SelectObject(pOldPen);
		pDC->SetTextColor(nOldFgColor);
		pDC->SetBkMode(nOldMode);

		pDC->SelectObject(pOldFont);
		
	}
	catch (CException* e)
	{
		TCHAR szMessage[_MAX_PATH] = {0};
		e->GetErrorMessage(szMessage, _MAX_PATH);
		TRACE(_T("\n CDciRvCtrl::UpdateControl... CException! [%s] \n"), szMessage);	
	}
}

void CDciRvCtrl::IndicateProdSensor(CDC * pDC, CRect rect, int ng, int ns, COLORREF nColor)
{
	pDC->FillSolidRect(rect.left+ng,		rect.top+ng,		ns, ns, nColor);
	pDC->FillSolidRect(rect.right-ng-ns,	rect.top+ng,		ns, ns, nColor);
	pDC->FillSolidRect(rect.left+ng,		rect.bottom-ng-ns,	ns, ns, nColor);
	pDC->FillSolidRect(rect.right-ng-ns,	rect.bottom-ng-ns,	ns, ns, nColor);	
}

BOOL CDciRvCtrl::SetClick(CWnd* pWnd, const CPoint& ptClickS)
{

	CString strTemp;

	switch (m_nForkType)
	{
	case enSingle:
		if (m_bClick = (m_rcForkS.PtInRect(ptClickS)))
			InvalidateControl(pWnd, FALSE);

//		strTemp.Format("Bottom = %d \nTop = %d \nLeft = %d \nRight = %d \nŬ������ = %d", m_rcForkS.bottom, m_rcForkS.top, m_rcForkS.left, m_rcForkS.right, m_bClick);
//		AfxMessageBox(strTemp);
		break;
	case enTwin:
		if (m_bClick = (m_rcForkS.PtInRect(ptClickS) || m_rcForkT.PtInRect(ptClickS)) )
			InvalidateControl(pWnd, FALSE);

//		strTemp.Format("Bottom = %d \nTop = %d \nLeft = %d \nRight = %d \nŬ������ = %d", m_rcForkT.bottom, m_rcForkT.top, m_rcForkT.left, m_rcForkT.right, m_bClick);
//		AfxMessageBox(strTemp);
		break;
	case enDouble:
		if (m_bClick = (m_rcForkS.PtInRect(ptClickS) || m_rcForkD.PtInRect(ptClickS)) )
			InvalidateControl(pWnd, FALSE);
		
//		strTemp.Format("Bottom = %d \nTop = %d \nLeft = %d \nRight = %d \nŬ������ = %d", m_rcForkD.bottom, m_rcForkD.top, m_rcForkD.left, m_rcForkD.right, m_bClick);
//		AfxMessageBox(strTemp);
		break;
	}

//	if (m_bClick = (m_rcForkS.PtInRect(ptClickS) || m_rcForkT.PtInRect(ptClickS) || m_rcForkD.PtInRect(ptClickS)) )
//		InvalidateControl(pWnd, FALSE);

	return m_bClick;
}
